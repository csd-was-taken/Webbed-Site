Put the other 3 files here in your My Stuff folder

if you don't know what that is: https://wiki.tockdom.com/wiki/My_Stuff_Folder