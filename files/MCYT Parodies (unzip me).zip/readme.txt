Install the resource pack like any other (https://minecraft.wiki/w/Tutorials/Loading_a_resource_pack).
Make sure it's at the top of the list.

Install the datapack onto the world of your choice (https://minecraft.wiki/w/Tutorials/Installing_a_data_pack).
Run the /reload command in game, and some text explaining the program i used should come up.

If you're in creative, you can run /function mcytparodies:give_all_discs to give yourself all of them.
Otherwise, the discs should drop like vanilla ones (https://minecraft.wiki/w/Music_Disc#Mob_loot). Note that
they will not generate in loot chests

i don't have any plans to port this to bedrock edition, but if you wanna take a crack at it then go for it.
if you're having any issues, don't bother the people who made Infinite Music Discs. or me either, it works fine
you're just doing something wrong and i won't be able to help.

Should work on servers, just make sure everyone has the resource pack.

a playlist with all the songs i used can be found here https://www.youtube.com/playlist?list=PLqIyFXIFpuS8B0qBdkJ36nBRD6znvynlY